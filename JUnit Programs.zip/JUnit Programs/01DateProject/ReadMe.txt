I explained why do we need a testing? 
What are the benefits of testing our applications?
Single Responsibility principle.
What happens if a class is having multiple responsibilities?


Problem statement :

We need to find the number of days between the two days without using predefined/built-in function(s).

1) First i explain the problem statement to the participants so that they get the clear idea about it.

2) Before starting actual coding part, i asked the participants about various possibilities of cases.

    For that i asked them to use Microsoft Excel where they can find the no. of days with different inputs.

3) Then, I explain the what is a correct way to write a program  i.e. first we need to write the client code and then we have to build the
    application classes (codes).

4) This example itself contains much more things about writing good programs.

