package com.pspl.date.tests;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

import com.pspl.date.app.Date;
import com.pspl.date.app.DateUtils;

public class DateUtilsTest {
	
	@Test
	public void testDuration() {
		assertEquals(0, DateUtils.duration(new Date(15,5,2016), new Date(15,5,2016)));
		assertEquals(4, DateUtils.duration(new Date(15,5,2016), new Date(19,5,2016)));
		assertEquals(95, DateUtils.duration(new Date(15,1,2016), new Date(19,4,2016)));
		assertEquals(35, DateUtils.duration(new Date(15,5,2016), new Date(19,6,2016)));
		assertEquals(32, DateUtils.duration(new Date(15,2,2017), new Date(19,3,2017)));
		assertEquals(33, DateUtils.duration(new Date(15,2,2016), new Date(19,3,2016)));
		assertEquals(64, DateUtils.duration(new Date(15,1,2016), new Date(19,3,2016)));
		assertEquals(65, DateUtils.duration(new Date(15,5,2016), new Date(19,7,2016)));
		assertEquals(96, DateUtils.duration(new Date(15,5,2016), new Date(19,8,2016)));
		assertEquals(218, DateUtils.duration(new Date(15,5,2016), new Date(19,12,2016)));
		assertEquals(249, DateUtils.duration(new Date(15,5,2016), new Date(19,1,2017)));
		assertEquals(583, DateUtils.duration(new Date(15,5,2016), new Date(19,12,2017)));
		assertEquals(948, DateUtils.duration(new Date(15,5,2016), new Date(19,12,2018)));
		assertEquals(1313, DateUtils.duration(new Date(15,5,2016), new Date(19,12,2019)));
		assertEquals(1679, DateUtils.duration(new Date(15,5,2016), new Date(19,12,2020)));
		assertEquals(5331, DateUtils.duration(new Date(15,5,2016), new Date(19,12,2030)));
		assertEquals(41855, DateUtils.duration(new Date(15,5,2016), new Date(19,12,2130)));
		assertEquals(187952, DateUtils.duration(new Date(15,5,2016), new Date(19,12,2530)));
		assertEquals(1283679, DateUtils.duration(new Date(15,5,2016), new Date(19,12,5530)));	
	}
}
