package com.pspl.stack.app;

import java.util.LinkedList;

import com.pspl.stack.app.exceptions.EmptyMyStackException;

public class MyStack<T> {

	private LinkedList<T> data = new LinkedList<T>();
	
	public void push(T value) {
		data.addLast(value);
	}
	
	public T pop() throws EmptyMyStackException {		
        if(data.isEmpty())
        	throw new EmptyMyStackException();
        else
        	return data.removeLast();
	}
	
	public T peek() throws EmptyMyStackException {
		if(data.isEmpty())
        	throw new EmptyMyStackException();
        else
        	return data.getLast();
	}
	
	public int size() {
		return data.size();
	}
}
