package com.pspl.stack.app.exceptions;

public class EmptyMyStackException extends Exception {
	
	public EmptyMyStackException() {
		super();
	}
		
	public EmptyMyStackException(String message) {
		super(message);
	}
}
