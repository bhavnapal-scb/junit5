package com.pspl.stack.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.pspl.stack.app.MyStack;
import com.pspl.stack.app.exceptions.EmptyMyStackException;

public class StackTest {

	private MyStack<String> stack;

	@Before
	public void setup() {
		stack = new MyStack<String>();
	}

	@Test
	public void testNewStackSizeIsZero() {
		assertEquals(0, stack.size());
	}

	@Test
	public void testPushAndPopChangeStackSizeByOne() throws EmptyMyStackException {
		stack.push("one");
		assertEquals(1, stack.size());
		stack.push("two");
		assertEquals(2, stack.size());
		stack.push("three");
		assertEquals(3, stack.size());
		stack.pop();
		assertEquals(2, stack.size());
		stack.pop();
		assertEquals(1, stack.size());
		stack.pop();
		assertEquals(0, stack.size());

	}

	@Test
	public void testPopReturnsTopmostObject() throws EmptyMyStackException {
		stack.push("one");
		stack.push("two");
		stack.push("three");
		assertTrue(stack.pop().equals("three"));
		assertTrue(stack.pop().equals("two"));
		assertTrue(stack.pop().equals("one"));
	}

	@Test
	public void testPeekReturnsTopmostObjectValueWithoutRemovingIt() throws EmptyMyStackException {
		stack.push("one");
		stack.push("two");
		stack.push("three");
		assertTrue(stack.peek().equals("three"));
		assertEquals(3, stack.size());
		assertTrue(stack.peek().equals("three"));

	}

	@Test(expected = EmptyMyStackException.class)
	public void testPopOnEmptyStackThrowsException() throws EmptyMyStackException {
		stack.pop();
	}

	@Test(expected = EmptyMyStackException.class)
	public void testPeekOnEmptyStackThrowsException() throws EmptyMyStackException {
		stack.peek();
	}
	
	@After
	public void tearDown() {
		stack = null;
	}
}
