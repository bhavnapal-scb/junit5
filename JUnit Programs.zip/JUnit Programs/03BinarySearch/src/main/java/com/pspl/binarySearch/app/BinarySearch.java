package com.pspl.binarySearch.app;

import com.pspl.binarySearch.app.exceptions.EmptyArrayException;

public class BinarySearch {

	public static int search(int[] data, int key) throws EmptyArrayException {
		
		if(data.length == 0)
			throw new EmptyArrayException();
		
		int low=0;
		int high=data.length-1;
		int mid = 0;
		
		while(low<=high) {
			mid = (low+high)/2;
			
			if(key == data[mid]) 
				return mid;			
			else if(key < data[mid]) 
				high = mid -1;
			else if(key > data[mid]) 
				low = mid + 1;
		}
		
		return -1;
	}
}
