package com.pspl.binarySearch.tests;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.pspl.binarySearch.app.BinarySearch;
import com.pspl.binarySearch.app.exceptions.EmptyArrayException;

public class BinarySearchTest {

	@Test(timeout = 10000)
	public void testArrayWithOddNumberOfElements() throws EmptyArrayException {
		int data[] = new int[] { 11, 22, 33, 44, 55, 66, 77 };

		assertEquals(0, BinarySearch.search(data, 11));
		assertEquals(1, BinarySearch.search(data, 22));
		assertEquals(3, BinarySearch.search(data, 44));
		assertEquals(6, BinarySearch.search(data, 77));
		assertEquals(-1, BinarySearch.search(data, 2));
		assertEquals(-1, BinarySearch.search(data, 51));
		assertEquals(-1, BinarySearch.search(data, 92));
	}

	@Test(timeout = 10000)
	public void testArrayWithEvenNumberOfElements() throws EmptyArrayException {
		int data[] = new int[] { 11, 22, 33, 44, 55, 66, 77, 88 };

		assertEquals(0, BinarySearch.search(data, 11));
		assertEquals(1, BinarySearch.search(data, 22));

		assertEquals(3, BinarySearch.search(data, 44));
		assertEquals(4, BinarySearch.search(data, 55));

		assertEquals(6, BinarySearch.search(data, 77));
		assertEquals(7, BinarySearch.search(data, 88));
		assertEquals(-1, BinarySearch.search(data, 2));
		assertEquals(-1, BinarySearch.search(data, 51));
		assertEquals(-1, BinarySearch.search(data, 92));
	}

	@Test(timeout = 10000)
	public void testArrayWithOnlyOneElement() throws EmptyArrayException {
		int data[] = new int[] { 11 };

		assertEquals(0, BinarySearch.search(data, 11));

		assertEquals(-1, BinarySearch.search(data, 9));
		assertEquals(-1, BinarySearch.search(data, 21));

	}

	@Test(expected = EmptyArrayException.class, timeout = 10000)
	public void testEmptyArray() throws EmptyArrayException {
		int data[] = new int[] {};

		assertEquals(-1, BinarySearch.search(data, 11));
	}

}
